import logging
from sqlalchemy.exc import IntegrityError
from datetime import datetime, timezone

from app.repositories.blacklist_repository import TokenBlacklistRepository
from app.repositories.user_repository import UserRepository
from app.db.models import User
from app.core.security import hash_password, verify_password
from app.core.jwt import create_access_token, create_refresh_token, decode_token
from app.core.exceptions import (
    UserAlreadyExistsError,
    InvalidCredentialsError,
    UserNotFoundError,
    InvalidTokenError,
    TokenRevokedError,
)

logger = logging.getLogger(__name__)


class AuthService:
    def __init__(self, repo: UserRepository, blacklist_repo: TokenBlacklistRepository):
        self.repo = repo
        self.blacklist_repo = blacklist_repo

    def register(self, email: str, password: str) -> dict[str, str | int]:
        email = self._normalize_email(email)

        if not password or not password.strip():
            logger.warning("Register failed: empty password email=%s", email)
            raise InvalidCredentialsError()

        if len(password.strip()) < 6:
            logger.warning("Register failed: password too short email=%s", email)
            raise InvalidCredentialsError()

        password_hash = hash_password(password)

        try:
            user = self.repo.create_user(email, password_hash)
        except IntegrityError:
            logger.warning("Register failed: user exists: %s", email)
            raise UserAlreadyExistsError()

        logger.info("User registered id=%s email=%s", user.id, email)

        tokens = self._generate_tokens(user)
        return self._build_auth_response(user, tokens)

    def login(self, email: str, password: str) -> dict[str, str | int]:
        email = self._normalize_email(email)

        user = self.repo.get_by_email(email)

        if not user or not verify_password(password, user.password_hash):
            logger.warning("Login failed email=%s", email)
            raise InvalidCredentialsError()

        logger.info("User login id=%s", user.id)

        tokens = self._generate_tokens(user)
        return self._build_auth_response(user, tokens)

    def refresh(self, refresh_token: str) -> dict[str, str | int]:
        payload = decode_token(
            refresh_token, expected_type="refresh", blacklist_repo=self.blacklist_repo
        )

        try:
            user_id = int(payload["sub"])
        except (KeyError, ValueError):
            logger.warning("Refresh failed: invalid subject")
            raise InvalidTokenError("Invalid subject")

        jti = payload.get("jti")
        if not jti:
            logger.warning("Refresh failed: missing jti")
            raise InvalidTokenError("Missing jti")

        expires_at = self._get_expires_at(payload)

        if self.blacklist_repo.is_blacklisted(jti):
            logger.warning("Refresh failed: token reused jti=%s", jti)
            raise TokenRevokedError("Token already used")

        self.blacklist_repo.add(jti, expires_at)

        user = self.repo.get_by_id(user_id)

        if not user:
            logger.warning("Refresh failed: user not found id=%s", user_id)
            raise UserNotFoundError()

        logger.info("User refreshed id=%s", user.id)

        tokens = self._generate_tokens(user)
        return self._build_auth_response(user, tokens)

    def get_current_user(self, token: str) -> User:
        payload = decode_token(
            token, expected_type="access", blacklist_repo=self.blacklist_repo
        )

        try:
            user_id = int(payload["sub"])
        except (KeyError, ValueError):
            logger.warning("Access token invalid subject")
            raise InvalidTokenError("Invalid subject")

        user = self.repo.get_by_id(user_id)

        if not user:
            logger.warning("User from token not found id=%s", user_id)
            raise UserNotFoundError()

        return user

    def logout(self, token: str):
        try:
            payload = decode_token(token, blacklist_repo=None)
        except InvalidTokenError:
            logger.warning("Logout failed: invalid token")
            return

        jti = payload.get("jti")
        if not jti:
            logger.warning("Logout failed: missing jti")
            return

        exp = payload.get("exp")
        if not exp:
            logger.warning("Logout failed: missing exp")
            return

        expires_at = datetime.fromtimestamp(exp, tz=timezone.utc)

        if not self.blacklist_repo.is_blacklisted(jti):
            self.blacklist_repo.add(jti, expires_at)
            logger.info("User logout jti=%s", jti)

    # HELPERS

    def _generate_tokens(self, user: User) -> dict[str, str]:
        payload = self._build_token_payload(user)
        return {
            "access_token": create_access_token(payload),
            "refresh_token": create_refresh_token(payload),
        }

    def _build_auth_response(self, user, tokens):
        return {
            **tokens,
            "token_type": "bearer",
            "user_id": user.id,
        }

    def _normalize_email(self, email: str) -> str:
        if not email:
            raise InvalidCredentialsError()
        return email.strip().lower()

    def _build_token_payload(self, user: User) -> dict[str, str]:
        return {
            "sub": str(user.id),
            "email": user.email,
        }

    def _get_expires_at(self, payload: dict) -> datetime:
        exp = payload.get("exp")
        if not exp:
            raise InvalidTokenError("Missing exp")

        if isinstance(exp, int):
            return datetime.fromtimestamp(exp, tz=timezone.utc)

        if isinstance(exp, datetime):
            return exp

        raise InvalidTokenError("Invalid exp format")
